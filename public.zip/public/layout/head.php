<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="styles/bootstrap3/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/css.css">

    <title>Marks MIS</title>
  </head>