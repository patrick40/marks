<div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <a href="" style="color: white"><h4>IT Department</h4></a>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu" id="menu">
                            <li class="active">
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>dashboard</span></a>
                                <ul class="collapse">
                                    <li class="active"><a href="<?php base(); ?>dashboard">Dashboard</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Courses
                                    </span></a>
                                <ul class="collapse">
                                    <li><a href="<?php base(); ?>courses">Manage Courses</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-slice"></i><span>Marks</span></a>
                                <ul class="collapse">
                                    <li><a href="<?php base(); ?>">Add Marks</a></li>
                                    <li><a href="<?php base(); ?>">View Marks</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-users"></i><span>Users</span></a>
                                <ul class="collapse">
                                    <li><a href="<?php base(); ?>users">Manage Users</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-pie-chart"></i><span>Reports</span></span></a>
                                <ul class="collapse">
                                    <li><a href="<?php base(); ?>">Transcript</a></li>
                                    <li><a href="<?php base(); ?>">General Reports</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-user"></i>
                                    <span>Profile</span></a>
                                <ul class="collapse">
                                    <li><a href="<?php base(); ?>profile">My Profile</a></li>
                                    <li><a href="<?php base(); ?>change_password">Change Password</a></li>
                                    <li><a href="<?php base(); ?>functions/logout.php">logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>