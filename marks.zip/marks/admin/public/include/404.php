<?php 
echo"<h1>the page is not found in admin </h1>";
?>