<div class="container">
    <?php errors(); message(); ?>
    <center>
        <img src="images/layout/ur.jfif" /><hr/>
        <div class="alert alert-primary"><h4>IT Department MIS</h4></div>
    </center>
</div>